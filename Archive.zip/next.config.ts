import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // output: 'export',  // Keep this commented out
  trailingSlash: true,
  images: {
    unoptimized: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  turbopack: {
    rules: {
      '*.svg': {
        loaders: ['@svgr/webpack'],
        as: '*.js',
      },
    },
  },
  webpack: (config) => {
    config.resolve.fallback = {
      ...config.resolve.fallback,
      fs: false,
      net: false,
      tls: false,
    };
    
    // Prevent bundling PDF.js worker files
    config.resolve.alias = {
      ...config.resolve.alias,
      'pdfjs-dist/build/pdf.worker.js': false,
      'pdfjs-dist/build/pdf.worker.mjs': false,
      'pdfjs-dist/legacy/build/pdf.worker.js': false,
      'pdfjs-dist/legacy/build/pdf.worker.mjs': false,
    };

    // Externalize server-only deps so the bundler won't traverse them
    config.externals = {
      ...(config.externals || {}),
      'canvas': 'commonjs canvas',
      'pdf-parse': 'commonjs pdf-parse',
    };
    
    return config;
  },

  // Disable worker at runtime
  env: {
    PDFJS_DISABLE_WORKER: 'true',
  },
};

export default nextConfig;