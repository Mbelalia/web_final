// Module partagé pour le traitement PDF

export type Product = {
  id: string;
  name: string;
  description?: string;
  quantity: number;
  priceHT?: number;
  priceTTC?: number;
  reference?: string;
};

// Fonction simplifiée pour utiliser pdf-parse directement
export async function loadPdfParse() {
  try {
    // Ensure worker is disabled
    process.env.PDFJS_DISABLE_WORKER = 'true';
    // Clear cache to get a fresh instance
    try {
      delete require.cache[require.resolve('pdf-parse')];
    } catch {}
    const pdfParse = eval('require')('pdf-parse');
    return pdfParse;
  } catch (e1) {
    try {
      const pdfParse = eval('require')('pdf-parse/dist/cjs/index.js');
      return pdfParse;
    } catch (e2) {
      const m: any = await import('pdf-parse');
      const fn = (m as any)?.default || (m as any)?.pdf || Object.values(m).find((v: any) => typeof v === 'function');
      if (typeof fn !== 'function') {
        throw new Error('Failed to load pdf-parse function');
      }
      return fn;
    }
  }
}

// Fonction pour normaliser le texte
export function normalizeText(text: string): string {
  return text
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/\s+/g, ' ')
    .trim();
}

// Fonction pour extraire un extrait pertinent
export function takeRelevantExcerpt(fullText: string, maxLength = 50000): string {
  if (fullText.length <= maxLength) {
    return fullText;
  }
  const halfLength = Math.floor(maxLength / 2);
  const start = fullText.substring(0, halfLength);
  const end = fullText.substring(fullText.length - halfLength);
  return start + "\n\n[...TEXTE TRONQUÉ...]\n\n" + end;
}