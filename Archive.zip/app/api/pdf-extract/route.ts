import { NextRequest, NextResponse } from "next/server";
import { jobQueue } from "../../../lib/jobQueue";

export const runtime = "nodejs";

// Configure pdfjs-dist worker before any PDF operations
process.env.PDFJS_DISABLE_WORKER = 'true';

// Product type definition
type Product = {
  id: string;
  name: string;
  description?: string;
  quantity: number;
  priceHT?: number;
  priceTTC?: number;
  reference?: string;
};

// Robust PDF parser loader with multiple fallback strategies
async function loadPdfParse() {
  // Do NOT require pdfjs-dist here; only load pdf-parse
  // Method 1: Direct require (bypasses module resolution issues)
  try {
    // CRITICAL FIX: Delete from require cache to prevent accumulation
    delete require.cache[require.resolve("pdf-parse")];
    const pdfParse = eval('require')("pdf-parse");
    console.log("✅ pdf-parse loaded successfully via require (fresh instance)");
    return pdfParse;
  } catch (requireError: unknown) {
    const errorMessage = requireError instanceof Error ? requireError.message : String(requireError);
    console.log("⚠️ require method failed:", errorMessage);
    
    // Method 2: Try direct CJS path
    try {
      const pdfParse = eval('require')("pdf-parse/dist/cjs/index.js");
      console.log("✅ pdf-parse loaded via CJS path");
      return pdfParse;
    } catch (cjsError: unknown) {
      const cjsErrorMessage = cjsError instanceof Error ? cjsError.message : String(cjsError);
      console.log("⚠️ CJS path failed:", cjsErrorMessage);
      
      // Method 3: Dynamic import with comprehensive fallbacks
      try {
        const m = await import("pdf-parse");
        // pdf-parse ESM export structure: look for named exports or the module itself
        const pdfParse = (m as any).pdf || (m as any).PDFParse || (m as any) || 
          Object.values(m).find(v => typeof v === 'function');
        
        if (typeof pdfParse === 'function') {
          console.log("✅ pdf-parse loaded via dynamic import");
          return pdfParse;
        }
        throw new Error("No valid function found in pdf-parse module");
      } catch (importError: unknown) {
        const importErrorMessage = importError instanceof Error ? importError.message : String(importError);
        console.log("❌ All loading methods failed:", importErrorMessage);
        throw new Error(`Failed to load pdf-parse: ${importErrorMessage}`);
      }
    }
  }
}

export async function POST(request: NextRequest) {
  try {
    // Debug the raw request
    console.log('🔍 Request headers:', Object.fromEntries(request.headers.entries()));
    console.log('🔍 Content-Type:', request.headers.get('content-type'));
    
    const formData = await request.formData();
    
    // Debug all FormData entries
    console.log('📋 All FormData entries:');
    for (const [key, value] of formData.entries()) {
      console.log(`  ${key}:`, {
        type: typeof value,
        constructor: value.constructor.name,
        isFile: value instanceof File,
        value: value instanceof File ? `File(${value.name}, ${value.size} bytes, ${value.type})` : value
      });
    }
    
    const file = formData.get("pdf") as File | null;
    const async = formData.get("async") === "true";
    
    // Enhanced debug logging
    console.log('📋 Received file:', {
      name: file?.name,
      type: file?.type,
      size: file?.size,
      hasFile: !!file,
      isFileInstance: file instanceof File,
      constructor: file?.constructor?.name,
      keys: file ? Object.keys(file) : 'no file'
    });
    
    if (!file) {
      console.log('❌ No file provided');
      return NextResponse.json({ error: "No PDF file provided" }, { status: 400 });
    }
    
    // Try to get file as Blob if File properties are undefined
    if (!file.name || !file.type || file.size === undefined) {
      console.log('⚠️ File properties undefined, treating as Blob');
      const blob = file as Blob;
      if (blob.size > 10 * 1024 * 1024) {
        return NextResponse.json({ error: "File too large (max 10MB)" }, { status: 400 });
      }
      // Continue with blob processing...
    } else {
      if (file.type !== "application/pdf") {
        console.log('❌ Wrong file type:', file.type);
        return NextResponse.json({ error: "File must be a PDF" }, { status: 400 });
      }
      
      if (file.size > 10 * 1024 * 1024) {
        console.log('❌ File too large:', file.size);
        return NextResponse.json({ error: "File too large (max 10MB)" }, { status: 400 });
      }
    }

    // CRITICAL FIX: Clear ALL cached modules that might have state
    const moduleKeys = Object.keys(require.cache).filter(key => 
      key.includes('pdfExtractor') || 
      key.includes('inventoryPdf') || 
      key.includes('pdfProcessor') ||
      key.includes('pdf-parse')
    );
    moduleKeys.forEach(key => {
      delete require.cache[key];
      console.log(`🧹 Cleared module cache: ${key}`);
    });

    // CRITICAL FIX: Create a completely fresh buffer for each request
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    
    // CRITICAL FIX: Clear any potential module-level state
    if (global.gc) {
      global.gc(); // Force garbage collection if available
    }
    
    if (async) {
      const userId = "user123";
      const jobId = await jobQueue.addJob(userId, file.name, buffer);
      
      return NextResponse.json({
        success: true,
        jobId,
        message: "Extraction en cours... Vous recevrez une notification une fois terminée."
      });
    }

    // CRITICAL FIX: Load PDF parser fresh for each request
    const pdfParse = await loadPdfParse();
    
    // CRITICAL FIX: Explicit variable scoping to prevent accumulation
    let extractedText: string;
    let parsed: any;
    {
      // Create isolated scope for PDF parsing
      parsed = await pdfParse(buffer, {
        max: 0, // No page limit
        version: 'v1.10.100' // Force specific version
      });
      
      // CRITICAL FIX: Ensure we get a completely fresh text string
      extractedText = String(parsed.text || '').trim();
    }
    
    // Additional cleanup to prevent accumulation
    extractedText = normalizeText(extractedText);
    
    if (!extractedText.trim()) {
      return NextResponse.json({ error: "Empty or unreadable PDF" }, { status: 422 });
    }

    console.log(`🔄 Fresh extraction: ${extractedText.length} characters from PDF`);
    
    // Take relevant excerpt for processing
    const excerpt = takeRelevantExcerpt(extractedText);
    
    // Extract products using LLM
    const products = await extractProductsWithLLM(excerpt);
    
    // CRITICAL FIX: Explicitly clear all variables and buffers
    extractedText = '';
    buffer.fill(0); // Clear buffer
    
    // CRITICAL FIX: Clear module cache for PDF-related modules after processing
    const postProcessModuleKeys = Object.keys(require.cache).filter(key => 
      key.includes('pdf')
    );
    postProcessModuleKeys.forEach(key => delete require.cache[key]);
    
    return NextResponse.json({
      success: true,
      products,
      extractedText: excerpt.substring(0, 1000),
      metadata: {
        pages: parsed?.numpages || 0,
        textLength: excerpt.length,
        productsFound: products.length
      }
    });
    
  } catch (error: any) {
    console.error('PDF extraction error:', error);
    return NextResponse.json(
      { error: 'Failed to extract PDF content' },
      { status: 500 }
    );
  }
}

// Normalize extracted text - IMPROVED for French characters
function normalizeText(text: string): string {
  return text
    .replace(/\s+/g, ' ') // Multiple spaces to single space
    // Keep French accented characters and common symbols
    .replace(/[^\w\s\-.,€$£¥àáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞŸ]/g, '')
    .trim();
}

// Take relevant excerpt from full text
function takeRelevantExcerpt(fullText: string, maxLength = 80000): string {
  // Augmenté de 50000 à 80000 pour traiter plus de contenu et éviter la troncature
  if (fullText.length <= maxLength) return fullText;
  
  // Si le texte est trop long, on prend le début et la fin
  const halfLength = Math.floor(maxLength / 2);
  const start = fullText.substring(0, halfLength);
  const end = fullText.substring(fullText.length - halfLength);
  return start + "\n\n[...TEXTE TRONQUÉ...]\n\n" + end;
}

// Extract products using Hostinger LLM
async function extractProductsWithLLM(text: string): Promise<Product[]> {
  try {
    const maxLength = 100000; // Increased from 50000
    const excerpt = takeRelevantExcerpt(text, maxLength);
    
    console.log(`Processing text with Ollama LLM (${excerpt.length} chars total)`);
    console.log(`Full original text length: ${text.length} chars`);
    
    // Log the full text content that will be sent to LLM
    console.log('='.repeat(80));
    console.log('FULL TEXT CONTENT TO BE PROCESSED BY LLM:');
    console.log('='.repeat(80));
    console.log(excerpt);
    console.log('='.repeat(80));
    console.log('END OF TEXT CONTENT');
    console.log('='.repeat(80));
    
    const ollamaEndpoint = process.env.HOSTINGER_LLM_ENDPOINT || 'https://ollama.mabeldev.com/api/generate';
    const ollamaApiKey = process.env.HOSTINGER_LLM_API_KEY;
    
    if (!ollamaEndpoint) {
      console.error('Ollama endpoint not configured, falling back to pattern matching');
      return fallbackExtraction(text);
    }
    
    console.log(`Using Ollama LLM URL: \`${ollamaEndpoint}\``);
    
    // IMPROVED PROMPT with clear field definitions
   const prompt = `
You are a product extraction expert. Extract ALL physical products from this invoice/order confirmation and return a valid JSON array.

REQUIRED JSON STRUCTURE:
[
  {
    "id": "unique-identifier",
    "name": "PRODUCT_NAME_ONLY",
    "description": "size, color, variant details",
    "quantity": 1,
    "priceTTC": 0.00,
    "priceHT": 0.00,
    "reference": "product-reference-or-sku"
  }
]

STRICT OUTPUT CONTRACT — DO NOT VIOLATE:
- Output ONLY a single top-level JSON array (no prose, no markdown).
- Exactly 7 keys per object: id, name, description, quantity, priceTTC, priceHT, reference.
- No placeholders, no missing keys. Numbers are JSON numbers (not strings).
- Return [] if nothing qualifies.

INCLUDE if it’s a tangible good (furniture, décor, clothing, etc.) with name + reference + price + quantity.
EXCLUDE delivery, services, eco-part, tax, totals, discounts, payment lines.

-------------------------------------
PRODUCT IDENTIFICATION STRATEGIES
-------------------------------------

🟦 IKEA FORMATS
- Use “Article numéro:” + pattern XXX.XXX.XX.
- Product name ends at first price.
- Description = text between first price and “Article numéro”.
- Quantity = number before last price.
- priceTTC = first price; priceHT = round(priceTTC / 1.20, 2).
- Ignore “Éco-part”, “Reprise”, “Service”.

🟩 LA REDOUTE / MARKETPLACE FORMATS
- Each product block starts with the **product name line** (e.g., “Applique en métal fer, Keinta” or “Vase OASIS”).
- Reference appears on the next line: “Ref : XXXXXXX”.
- Then optional “Couleur : …”, “Taille : …”, and “Quantité : …” lines.
- The first standalone numeric + “€” after that block is the total TTC price for all quantities.
  → Compute unit price = total / quantity.
- If “dont X,XX € d’éco-participation” exists, subtract it before dividing.
- priceHT = round(priceTTC / 1.20, 2) unless explicitly given.
- description = combine available “Couleur”, “Taille”, and other descriptors.
- Marketplace blocks (“vendus et expédiés par …”) follow same pattern but may lack “Ref :”; keep if name + price + quantity exist.

🟨 GENERIC / AMAZON-LIKE
- Detect “ASIN:”, “SKU:”, “Product code:”, “Item #”, etc.
- Use similar name → price → quantity → ref logic.

-------------------------------------
NORMALIZATION
-------------------------------------
- Convert “24,99 €” → 24.99; remove € and spaces.
- Thousands “1 234,50 €” → 1234.50.
- Quantity always integer ≥ 1.
- Deduplicate by reference (sum quantities, keep best description).
- Ignore eco-part, taxes, totals, discounts, payments.

-------------------------------------
VALIDATION
-------------------------------------
1. Output must be a single valid JSON array.
2. Each object has 7 required keys.
3. reference non-empty and plausible.
4. priceTTC and priceHT are unit prices.
5. Exclude services or delivery lines.

-------------------------------------
VENDOR-SPECIFIC PATTERNS TO RECOGNIZE
-------------------------------------
IKEA → “Article numéro: XXX.XXX.XX”
La Redoute → “Ref : XXXXXXX”, followed by “Couleur : …”, “Taille : …”, “Quantité : …”
Marketplace → “vendu et expédié par …” blocks, usually ending with a line containing a price in euros
Amazon → “ASIN:”, “SKU:”
Generic → Columns or blocks: Item | Qty | Price

TEXT TO ANALYZE:
${excerpt}`;



    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 1200000);
    
    let response, data, rawResponse;
    
    try {
      response = await fetch(ollamaEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(ollamaApiKey && { 'Authorization': `Bearer ${ollamaApiKey}` })
        },
        body: JSON.stringify({
          model: 'mistral:latest',
          prompt: prompt,
          stream: false,
          options: {
            temperature: 0.02,
            top_p: 0.7,
            num_predict: 40000
          }
        }),
        signal: controller.signal
      });
      
      if (!response.ok) {
        throw new Error(`Ollama LLM API error: ${response.status} ${response.statusText}`);
      }
      
      data = await response.json();
      rawResponse = data.response || data.text || JSON.stringify(data);
    } finally {
      clearTimeout(timeoutId);
    }
    
    console.log(`Raw Ollama LLM response: ${rawResponse}`);
    
    // After getting rawResponse, add this parsing logic
    if (rawResponse.includes('**') && rawResponse.includes('* Nom :')) {
      // Parse the structured format
      const products = [];
      const productSections = rawResponse.split(/\d+\. \*\*/).filter((section: string) => section.trim());
      
      for (const section of productSections) {
        const lines = section.split('\n').map((line: string) => line.trim()).filter((line: string) => line);
        const product: any = { id: '', name: '', description: '', quantity: 1, priceTTC: 0, priceHT: 0, reference: '' };
        
        // Extract product name from first line
        const nameMatch = lines[0].match(/^(.+?)\*\*/);
        if (nameMatch) {
          product.name = nameMatch[1].trim();
        }
        
        // Parse bullet points
        for (const line of lines) {
          if (line.includes('* Nom :')) {
            product.name = line.replace('* Nom :', '').trim();
          } else if (line.includes('* Quantité :')) {
            const qty = line.replace('* Quantité :', '').trim();
            product.quantity = parseInt(qty) || 1;
          } else if (line.includes('* Description :')) {
            product.description = line.replace('* Description :', '').trim();
          } else if (line.includes('* Reference :')) {
            const ref = line.replace('* Reference :', '').trim();
            product.reference = ref.replace(/^.*Ref\s*/, '').replace(/\?$/, '').trim();
          } else if (line.includes('* Prix TTC :')) {
            const price = line.replace('* Prix TTC :', '').replace('€', '').trim();
            product.priceTTC = parseFloat(price.replace(',', '.')) || 0;
          }
        }
        
        product.id = product.reference || `prod-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        products.push(product);
      }
      
      // Convert to JSON string for existing parsing logic
      rawResponse = JSON.stringify(products);
    }
    
    // Improved JSON extraction to handle verbose responses
    let cleanContent = rawResponse.trim();
    
    // Remove common prefixes in French
    const prefixesToRemove = [
      /^Voici le JSON[^:]*:\s*/i,
      /^Le JSON[^:]*:\s*/i,
      /^Résultat[^:]*:\s*/i,
      /^Voici[^:]*:\s*/i,
      /^Voici les produits[^:]*:\s*/i
    ];
    
    for (const prefix of prefixesToRemove) {
      cleanContent = cleanContent.replace(prefix, '');
    }
    
    // Extract JSON from markdown code blocks
    const codeBlockMatch = cleanContent.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
    if (codeBlockMatch) {
      cleanContent = codeBlockMatch[1].trim();
    }
    
    // Check if the response is a structured product format
    if (cleanContent.includes('**Produit') && cleanContent.includes('* Nom :')) {
      console.log('Converting structured product format to JSON');
      
      // Split by product sections - improved regex to handle complex cases
      const productMatches = cleanContent.match(/\*\*Produit \d+[^*]*\*\*([\s\S]*?)(?=\*\*Produit \d+|$)/g);
      
      const products = [];
      
      if (productMatches) {
        for (const productMatch of productMatches) {
          const section = productMatch.replace(/\*\*Produit \d+[^*]*\*\*/, '').trim();
          
          // Handle complex products with sub-entries (like BLODFLÄDER)
            if (section.includes(' + Quantité :')) {
              // Split by sub-entries - improved regex
              const subEntries = section.split(/\n\s*\+\s*Quantité\s*:\s*(\d+)/);
              const mainSection = subEntries[0];
              
              // Parse main product info
              let baseName = '';
              const mainLines = mainSection.split('\n').filter((line: string) => line.trim().startsWith('*'));
              
              for (const line of mainLines) {
                const cleanLine = line.replace(/^\*\s*/, '').trim();
                if (cleanLine.startsWith('Nom :')) {
                  baseName = cleanLine.replace('Nom :', '').trim();
                  // Remove parenthetical info like "(2 fois)"
                  baseName = baseName.replace(/\s*\([^)]*\)\s*$/, '').trim();
                }
              }
              
              // Parse each sub-entry - improved parsing
              for (let i = 1; i < subEntries.length; i += 2) {
                const quantity = parseInt(subEntries[i]) || 1;
                const subEntryContent = subEntries[i + 1] || '';
                
                let priceTTC = 0, priceHT = 0, reference = '';
                
                // Parse the content after the quantity
                const lines = subEntryContent.split('\n');
                
                for (const line of lines) {
                  const cleanLine = line.replace(/^\s*\+\s*/, '').trim();
                  
                  if (cleanLine.startsWith('Prix TTC :')) {
                    const priceMatch = cleanLine.match(/([\d,]+)/);
                    priceTTC = priceMatch ? parseFloat(priceMatch[1].replace(',', '.')) : 0;
                  } else if (cleanLine.startsWith('Prix HT :')) {
                    const priceMatch = cleanLine.match(/([\d,]+)/);
                    priceHT = priceMatch ? parseFloat(priceMatch[1].replace(',', '.')) : 0;
                  } else if (cleanLine.startsWith('Reference :')) {
                    reference = cleanLine.replace('Reference :', '').trim();
                    if (reference === 'non disponible' || reference === 'non spécifié') {
                      reference = '';
                    }
                  }
                }
                
                if (baseName && !baseName.toLowerCase().includes('éco-part')) {
                  const id = (baseName + reference).toLowerCase().replace(/[^a-z0-9]/g, '') || `product_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
                  
                  products.push({
                    id: id,
                    name: baseName,
                    description: '',
                    quantity: quantity,
                    priceTTC: priceTTC,
                    priceHT: priceHT,
                    reference: reference
                  });
                }
              }
          } else {
            // Handle regular single products
            const lines = section.split('\n').filter((line: string) => line.trim().startsWith('*'));
            
            let name = '', quantity = 1, priceTTC = 0, priceHT = 0, reference = '';
            
            for (const line of lines) {
              const cleanLine = line.replace(/^\*\s*/, '').trim();
              
              if (cleanLine.startsWith('Nom :')) {
                name = cleanLine.replace('Nom :', '').trim();
                // Remove parenthetical info
                name = name.replace(/\s*\([^)]*\)\s*$/, '').trim();
              } else if (cleanLine.startsWith('Quantité :')) {
                const qtyMatch = cleanLine.match(/\d+/);
                quantity = qtyMatch ? parseInt(qtyMatch[0]) : 1;
              } else if (cleanLine.startsWith('Prix TTC :')) {
                const priceMatch = cleanLine.match(/([\d,]+)/);
                priceTTC = priceMatch ? parseFloat(priceMatch[1].replace(',', '.')) : 0;
              } else if (cleanLine.startsWith('Prix HT :')) {
                const priceMatch = cleanLine.match(/([\d,]+)/);
                priceHT = priceMatch ? parseFloat(priceMatch[1].replace(',', '.')) : 0;
              } else if (cleanLine.startsWith('Reference :')) {
                reference = cleanLine.replace('Reference :', '').trim();
                if (reference === 'non disponible' || reference === 'non spécifié') {
                  reference = '';
                }
              }
            }
            
            // Filter out eco-part products and ensure valid name
            if (name && !name.toLowerCase().includes('éco-part') && name !== 'non spécifié') {
              const id = (name + reference).toLowerCase().replace(/[^a-z0-9]/g, '') || `product_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
              
              products.push({
                id: id,
                name: name,
                description: '',
                quantity: quantity,
                priceTTC: priceTTC,
                priceHT: priceHT,
                reference: reference
              });
            }
          }
        }
      }
      
      cleanContent = JSON.stringify(products);
      console.log(`Converted structured format to JSON: ${cleanContent}`);
    }
    // Check if the response is a bullet-point list format
    else if (cleanContent.includes('- ') && !cleanContent.trim().startsWith('[')) {
      console.log('Converting bullet-point list to JSON format');
      
      // Parse bullet-point list and convert to JSON
      const lines = cleanContent.split('\n').filter((line: string) => line.trim().startsWith('- '));
      const products = [];
      
      for (const line of lines) {
        const cleanLine = line.replace(/^-\s*/, '').trim();
        
        // Extract product name (usually in CAPS at the beginning)
        const nameMatch = cleanLine.match(/^([A-ZÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞ][A-ZÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞ\s]*?)\s/);
        const name = nameMatch ? nameMatch[1].trim() : 'Produit sans nom';
        
        // Extract price with improved regex (handles more formats)
        const priceMatches = cleanLine.match(/(\d+[,.])?\d+[,.]\d{2}\s*€?/g) || 
                           cleanLine.match(/\d+\s*€/g) || 
                           cleanLine.match(/(\d+[,.])?\d+[,.]\d+/g);
        let price = 0;
        if (priceMatches && priceMatches.length > 0) {
          const lastPrice = priceMatches[priceMatches.length - 1];
          price = parseFloat(lastPrice.replace(',', '.').replace('€', '').trim());
        }
        
        // In the bullet-point conversion section, improve description cleaning:
        
        // Extract description (everything between name and price)
        let description = cleanLine.replace(nameMatch ? nameMatch[0] : '', '');
        if (priceMatches && priceMatches.length > 0) {
          const lastPriceMatch = priceMatches[priceMatches.length - 1];
          const priceIndex = description.lastIndexOf(lastPriceMatch);
          if (priceIndex > -1) {
            description = description.substring(0, priceIndex).trim();
          }
        }
        // Clean up description - remove leading dashes and trailing dashes
        description = description.replace(/^-\s*/, '').replace(/\s*-\s*$/, '').trim();
        
        // Generate ID from name or use timestamp
        const id = name.toLowerCase().replace(/[^a-z0-9]/g, '') || `product_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        // Add product regardless of price (price can be 0)
        products.push({
          id: id,
          name: name,
          description: description,
          quantity: 1,
          priceTTC: price > 0 ? price : 0
        });
      }
      
      cleanContent = JSON.stringify(products);
      console.log(`Converted to JSON: ${cleanContent}`);
    }
    
    // Remove any remaining explanatory text before/after JSON
    let jsonMatch = cleanContent.match(/(\[[\s\S]*\])/);
    if (jsonMatch) {
      cleanContent = jsonMatch[1];
    } else {
      // Try to extract from object with "articles" property
      const objectMatch = cleanContent.match(/(\{[\s\S]*\})/);
      if (objectMatch) {
        try {
          const parsedObject = JSON.parse(objectMatch[1]);
          if (parsedObject.articles && Array.isArray(parsedObject.articles)) {
            cleanContent = JSON.stringify(parsedObject.articles);
          }
        } catch (e) {
          // If parsing fails, keep the original content
        }
      }
    }
    
    console.log(`Cleaned content: ${cleanContent}`);
    
    // Fix French number format (commas to dots) before parsing
    const fixedContent = cleanContent.replace(/"(priceHT|priceTTC|quantity)":\s*(\d+),(\d+)/g, '"$1": $2.$3');
    
    console.log(`Fixed number format: ${fixedContent}`);
    
    const products = JSON.parse(fixedContent);
    
    // Validate that we got an array
    if (!Array.isArray(products)) {
      throw new Error('LLM response is not an array');
    }
    
    // ENHANCED POST-PROCESSING VALIDATION
    const validProducts = products
      .filter(product => product && typeof product === 'object')
      .map(product => {
        // Extract and clean reference from description or dedicated field
        let reference = String(product.reference || '').trim(); // Fix: Convert to string first
        let description = String(product.description || '').trim();
        
        // Extract article numbers from description and move to reference
        const articleMatches = description.match(/(?:Article numéro|Ref\.?|Référence)\s*:?\s*([\d\.]+)/gi);
        if (articleMatches && !reference) {
          const lastMatch = articleMatches[articleMatches.length - 1];
          const refMatch = lastMatch.match(/([\d\.]+)/);
          if (refMatch) {
            reference = refMatch[1];
            // Remove article number from description
            description = description.replace(lastMatch, '').trim();
          }
        }
        
        // Clean quantity field - extract only numbers
        let quantity = 1;
        const quantityStr = String(product.quantity || '1');
        
        // If quantity contains dimensions, colors, or text, extract number or default to 1
        const quantityMatch = quantityStr.match(/^(\d+)/);
        if (quantityMatch) {
          quantity = parseInt(quantityMatch[1]);
        } else if (quantityStr.match(/^\d+$/)) {
          quantity = parseInt(quantityStr);
        }
        
        // Move dimensions and colors from quantity to description
        const dimensionColorMatch = quantityStr.match(/(\d+x\d+\s*cm|\d+\s*cm|[a-zA-Z]+\s+[a-zA-Z]+|blanc|noir|gris|rouge|bleu|vert|jaune|orange|violet|rose|marron|beige)/gi);
        if (dimensionColorMatch && !description.includes(dimensionColorMatch[0])) {
          description = dimensionColorMatch.join(', ') + (description ? ', ' + description : '');
        }
        
        // Calculate unit price when quantity > 1
        let unitPriceTTC = parseFloat(String(product.priceTTC || 0).replace(',', '.')) || 0;
        let unitPriceHT = parseFloat(String(product.priceHT || 0).replace(',', '.')) || 0;
        
        // If quantity > 1 and price seems to be total price, divide by quantity to get unit price
        if (quantity > 1) {
          // Check if this looks like a total price (price is roughly quantity * unit_price)
          const potentialUnitPrice = unitPriceTTC / quantity;
          
          // If the division results in a reasonable unit price (not too many decimals)
          if (potentialUnitPrice > 0 && (potentialUnitPrice * 100) % 1 < 0.1) {
            console.log(`Dividing price for ${product.name}: ${unitPriceTTC}€ ÷ ${quantity} = ${potentialUnitPrice.toFixed(2)}€`);
            unitPriceTTC = Math.round(potentialUnitPrice * 100) / 100; // Round to 2 decimals
            if (unitPriceHT > 0) {
              unitPriceHT = Math.round((unitPriceHT / quantity) * 100) / 100;
            }
          }
        }
        
        return {
          id: product.id || `product_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          name: String(product.name || 'Produit sans nom').trim(),
          description: description.replace(/\s+/g, ' ').trim(),
          quantity: Math.max(1, quantity),
          priceHT: unitPriceHT,
          priceTTC: unitPriceTTC,
          reference: reference
        };
      })
      // Enhanced filtering for suspicious patterns
      .filter(product => {
        const name = product.name.toLowerCase();
        const suspiciousPatterns = [
          'total', 'sous-total', 'livraison', 'frais', 'tva', 'eco-participation',
          
          'exemple', 'example', 'produit sans nom'
        ];
        
        const isSuspicious = suspiciousPatterns.some(pattern => name.includes(pattern));
        if (isSuspicious) {
          console.log(`Produit filtré (suspect): ${product.name}`);
          return false;
        }
        
        // Validate name length and content
        if (!product.name.trim() || product.name.trim().length < 2) {
          console.log(`Produit filtré (nom trop court): ${product.name}`);
          return false;
        }
        
        // Filter products with dimensions in name (should be in description)
        if (product.name.match(/\d+x\d+\s*cm|\d+\s*cm/)) {
          console.log(`Produit filtré (dimensions dans le nom): ${product.name}`);
          return false;
        }
        
        return true;
      })
      // Cross-validation with original text
      .filter(product => {
        const nameWords = product.name.split(' ').filter(word => word.length > 2);
        const textLower = text.toLowerCase();
        
        const foundWords = nameWords.filter(word => 
          textLower.includes(word.toLowerCase())
        );
        
        const validationRatio = foundWords.length / nameWords.length;
        if (validationRatio < 0.5) { // Slightly more lenient
          console.log(`Produit filtré (nom non trouvé dans le texte): ${product.name}`);
          return false;
        }
        
        return true;
      })
      .slice(0, 50);
    
    // Enhanced description cleaning
    const cleanedProducts = validProducts.map(product => {
      let description = product.description;
      
      // Remove references to other extracted products
      validProducts.forEach(otherProduct => {
        if (otherProduct.name !== product.name) {
          const otherNameWords = otherProduct.name.split(' ').filter(word => word.length > 3);
          otherNameWords.forEach(word => {
            if (description.toLowerCase().includes(word.toLowerCase()) && description !== product.name) {
              console.log(`Nettoyage description de "${product.name}": suppression de "${word}"`);
              const regex = new RegExp(word, 'gi');
              description = description.replace(regex, '').trim();
            }
          });
        }
      });
      
      // Clean up extra spaces and punctuation
      description = description
        .replace(/\s+/g, ' ')
        .replace(/^[,\s]+|[,\s]+$/g, '')
        .trim();
      
      return {
        ...product,
        description
      };
    });
    
    // Add deduplication logic for products with same reference
    const deduplicatedProducts : Product[] = [];
    const seenReferences = new Map();
    
    for (const product of cleanedProducts) {
      const key = product.reference || product.name;
      
      if (seenReferences.has(key)) {
        const existing = seenReferences.get(key);
        
        // Keep the entry with quantity > 1 and reasonable unit price
        if (product.quantity > 1 && existing.quantity === 1) {
          console.log(`Déduplication: Remplacement de "${existing.name}" (qty=${existing.quantity}, prix=${existing.priceTTC}€) par "${product.name}" (qty=${product.quantity}, prix=${product.priceTTC}€)`);
          // Replace existing with current product
          const existingIndex = deduplicatedProducts.findIndex(p => (p.reference || p.name) === key);
          if (existingIndex !== -1) {
            deduplicatedProducts[existingIndex] = product;
          }
          seenReferences.set(key, product);
        } else if (existing.quantity > 1 && product.quantity === 1) {
          console.log(`Déduplication: Conservation de "${existing.name}" (qty=${existing.quantity}) au lieu de "${product.name}" (qty=${product.quantity})`);
          // Keep existing, skip current
          continue;
        } else {
          // If both have same quantity, keep the one with lower unit price (more likely correct)
          if (product.priceTTC < existing.priceTTC) {
            console.log(`Déduplication: Remplacement par prix unitaire plus bas: ${product.priceTTC}€ vs ${existing.priceTTC}€`);
            const existingIndex = deduplicatedProducts.findIndex(p => (p.reference || p.name) === key);
            if (existingIndex !== -1) {
              deduplicatedProducts[existingIndex] = product;
            }
            seenReferences.set(key, product);
          } else {
            console.log(`Déduplication: Conservation du prix existant: ${existing.priceTTC}€ vs ${product.priceTTC}€`);
            continue;
          }
        }
      } else {
        deduplicatedProducts.push(product);
        seenReferences.set(key, product);
      }
    }
    
    console.log(`Successfully extracted ${deduplicatedProducts.length} products from LLM (after deduplication)`);
    console.log(`Texte PDF total: ${text.length} caractères`);
    console.log(`Texte traité: ${excerpt.length} caractères`);
    
    deduplicatedProducts.forEach((product, index) => {
      console.log(`${index + 1}. "${product.name}" - ${product.priceTTC}€ (qty: ${product.quantity}) [Ref: ${product.reference || 'N/A'}]`);
    });
    
    return deduplicatedProducts;
    
  } catch (error: any) {
    if (error.name === 'AbortError' || error.code === 'UND_ERR_HEADERS_TIMEOUT') {
      console.log('LLM request timed out, using fallback extraction');
      return fallbackExtraction(text);
    }
    console.error('Failed to parse Hostinger LLM JSON response:', error);
    console.log('Using fallback pattern matching extraction');
    return fallbackExtraction(text);
  }
}

// Fallback extraction using pattern matching
function fallbackExtraction(text: string): Product[] {
  console.log("Using fallback pattern matching extraction");
  
  const lines = text.split('\n').filter(line => line.trim());
  const products: Product[] = [];
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const lowerLine = line.toLowerCase();
    
    // Expanded pattern matching for various product indicators
    const hasProductIndicators = (
      // French terms
      lowerLine.includes('produit') || lowerLine.includes('article') || 
      lowerLine.includes('référence') || lowerLine.includes('ref') ||
      // English terms
      lowerLine.includes('product') || lowerLine.includes('item') ||
      lowerLine.includes('description') || lowerLine.includes('qty') ||
      lowerLine.includes('quantity') || lowerLine.includes('price') ||
      // Patterns
      /\\b\\d+\\s*x\\s*/.test(lowerLine) || // "2 x" pattern
      /\\d+\\s*(€|\\$|£|usd|eur)/.test(lowerLine) || // Price patterns
      /\\b(ref|sku|code)\\s*[:#]?\\s*[a-z0-9\\-]+/i.test(line) || // Reference codes
      /\\b\\d+[.,]\\d{2}\\s*(€|\\$|£)/.test(line) // Decimal prices
    );
    
    if (hasProductIndicators) {
      const words = line.split(/\\s+/);
      
      // Look for quantities and prices
      const quantities = words.filter(w => /^\\d+$/.test(w));
      const prices = words.filter(w => /\\d+[.,]\\d*\\s*(€|\\$|£)/i.test(w));
      
      if (quantities.length > 0 || prices.length > 0) {
        const product: Product = {
          id: `fallback-${Date.now()}-${i}`,
          name: extractProductName(line),
          description: line.length > 100 ? line.substring(0, 100) + '...' : line,
          quantity: quantities.length > 0 ? coerceInt(quantities[0]) : 1,
          priceHT: prices.length > 0 ? coercePrice(prices[0]) : undefined,
          reference: extractReference(line)
        };
        
        products.push(product);
      }
    }
  }
  
  return products.slice(0, 50);
}

// Helper function to extract product name
function extractProductName(line: string): string {
  // Remove common prefixes and clean up
  const cleaned = line
    .replace(/^(produit|article|référence|ref|item)\s*:?\s*/i, '')
    .replace(/\d+\s*(€|\$|£).*$/, '')
    .replace(/qty\s*:?\s*\d+/i, '')
    .trim();
  
  return cleaned.length > 0 ? cleaned : 'Produit sans nom';
}

// Helper function to extract reference
function extractReference(line: string): string | undefined {
  const refMatch = line.match(/(?:ref|référence|reference)\s*:?\s*([A-Z0-9\-]+)/i);
  return refMatch ? refMatch[1] : undefined;
}

// Helper function to coerce integer values
function coerceInt(value: any, defaultValue = 1): number {
  const parsed = parseInt(String(value), 10);
  return isNaN(parsed) ? defaultValue : Math.max(1, parsed);
}

// Helper function to coerce price values
function coercePrice(value: any): number | undefined {
  if (!value) return undefined;
  const cleaned = String(value).replace(/[^\d.,]/g, '').replace(',', '.');
  const parsed = parseFloat(cleaned);
  return isNaN(parsed) ? undefined : parsed;
}